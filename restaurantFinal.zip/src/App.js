import './App.css';
import FoodItems from './components/FoodItem';
import Orderform from './components/OrderForm';

const food = [
      {
        dishType: 'Veg',
        dishName: 'Panner Tikka',
        dishPrice: 'INR 200'
      },
      {
        dishType: 'Veg',
        dishName: 'Panner Tikka Masala',
        dishPrice: 'INR 220'
      },
      {
        dishType: 'Non-veg',
        dishName: 'Chicken Curry',
        dishPrice: 'INR 300'
      },
      {
        dishType:'Veg',
        dishName: 'Panner Bhurji',
        dishPrice: 'INR 180'
      },
      {
        dishType:'Non-veg',
        dishName: 'Egg Bhurji',
        dishPrice: 'INR 180'
      },
      {
        dishType:'Veg',
        dishName: 'Panner Masala',
        dishPrice: 'INR 180'
      }
]

function App() {
  return (
    <div className="App">
      <Orderform/>
      <hr/>
      <h1>Food Menu : </h1>
      {
        food.map((item)=>
            <FoodItems dishName={item.dishName} dishPrice={item.dishPrice} dishType={item.dishType}></FoodItems>
      )}
      <hr/>
      <h1>Drinks Menu : </h1>
    </div>
  );
}

export default App;
